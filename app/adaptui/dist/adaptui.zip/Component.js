sap.ui.define(["sap/fe/core/AppComponent"],function(n){"use strict";const e=n.extend("ns.adaptui.Component",{metadata:{manifest:"json"}});return e});
//# sourceMappingURL=Component.js.map